IFS-ETC
=======

Exposure time calculator for CSST-IFS.


